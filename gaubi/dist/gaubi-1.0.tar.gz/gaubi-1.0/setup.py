from setuptools import setup

setup(name='gaubi',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['gaubi'],
      author='Gabriel Estivalet',
      author_email='gestivalet@gmail.com',
      zip_safe=False)
